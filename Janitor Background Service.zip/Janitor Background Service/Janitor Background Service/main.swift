//
//  main.swift
//  Janitor Background Service
//
//  Created by Ben Leggiero on 7/17/19.
//  Copyright © 2019 Ben Leggiero. All rights reserved.
//

import Foundation

print("Hello, World!")

